from minION.interface import execute_MinION
def main():
    execute_MinION()
                
if __name__ == "__main__":
    main()
